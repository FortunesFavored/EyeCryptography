msg = {
    'pair01': {
        'a': '1cf72f99',
        'b': '8634c1ef'
    },
    'pair02': {
        'a': '2ca1f81b',
        'b': '981e2346'
    },
    'pair03': {
        'a': '2e474a1f',
        'b': '29848a73'
    },
    'pair04': {
        'a': 'e1637be9',
        'b': '75a31019'
    },
    'pair05': {
        'a': 'b914ade3',
        'b': 'e2cfe1d3'
    },
    'pair06': {
        'a': 'b723d349',
        'b': '786f45ab'
    },
    'pair07': {
        'a': '48c7c97b',
        'b': 'bee5b2a5'
    },
    'pair08': {
        'a': 'ef63311a',
        'b': '2cbc058b'
    },
    'pair09': {
        'a': '655c358a',
        'b': 'ae1bc859'
    },
    'pair10': {
        'a': '797cd4b3',
        'b': '805b0e68'
    },
    'pair11': {
        'a': '64bf17b9',
        'b': '87eb66f8'
    },
    'pair12': {
        'a': 'c737f7dd',
        'b': '40a4cabc'
    },
    'pair13': {
        'a': '4f299b43',
        'b': '8dfe0c08'
    },
    'pair14': {
        'a': 'e0b4b2f4',
        'b': '2aabf66d'
    },
    'pair15': {
        'a': 'fae456c4',
        'b': '5a0d593c'
    },
    'pair16': {
        'a': '72a8e6a',
        'b': '2b885f6a'
    },
    'pair17': {
        'a': '616cf703',
        'b': '2d28'
    }
}